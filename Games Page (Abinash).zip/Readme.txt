## 🚀 Game Page README

* Run it **only with Live Server** — otherwise the JS modules won’t load and everything cries.
* You can start from **login.html** *or* **index.html** — both launch the fun.

Enjoy the chaos 🍀🎮